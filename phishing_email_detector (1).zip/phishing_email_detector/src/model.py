from sklearn.linear_model import LogisticRegression
model=LogisticRegression()