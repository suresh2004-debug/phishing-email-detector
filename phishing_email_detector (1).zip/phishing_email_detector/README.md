# Phishing Detector
Simple ML project.